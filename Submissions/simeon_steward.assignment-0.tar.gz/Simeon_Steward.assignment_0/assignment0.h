#define SIZE 23
void displayTable(int table[SIZE][SIZE]);
void spill(int table[SIZE][SIZE],int x,int y);
